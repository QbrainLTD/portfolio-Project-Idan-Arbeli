import { getCountries } from "./countries.js";
import { createCardList } from "./dombuilder.js";

// await getCountries();
createCardList();
